package com.kh.hellomentor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellomentorApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellomentorApplication.class, args);
	}

}
