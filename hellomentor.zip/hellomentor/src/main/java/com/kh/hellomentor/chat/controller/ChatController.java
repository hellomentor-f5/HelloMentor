package com.kh.hellomentor.chat.controller;

public class ChatController {
}
