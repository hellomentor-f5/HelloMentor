package com.kh.hellomentor.chat.model.dao;

public class ChatDao {
}
