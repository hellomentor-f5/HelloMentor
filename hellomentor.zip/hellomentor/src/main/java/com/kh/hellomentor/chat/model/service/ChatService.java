package com.kh.hellomentor.chat.model.service;

public interface ChatService {
}
