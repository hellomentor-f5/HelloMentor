package com.kh.hellomentor.chat.model.service;

public class ChatServiceImpl implements ChatService{
}
