package com.kh.hellomentor.matching.model.dao;

public class MatchingDao {
}
