package com.kh.hellomentor.matching.model.service;

public interface MatchingService {
}
