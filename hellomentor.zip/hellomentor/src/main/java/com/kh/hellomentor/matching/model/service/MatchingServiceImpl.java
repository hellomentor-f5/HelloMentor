package com.kh.hellomentor.matching.model.service;

public class MatchingServiceImpl implements MatchingService{
}
