package com.kh.hellomentor.notification.model.dao;

public class NotificationDao {
}
