package com.kh.hellomentor.notification.model.service;

public interface NotificationService {
}
