package com.kh.hellomentor.notification.model.service;

public class NotificationServiceImpl implements NotificationService{
}
