package com.kh.hellomentor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellomentorApplicationTests {

	@Test
	void contextLoads() {
	}

}
